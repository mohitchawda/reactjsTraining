import logo from './logo.svg';
import './App.css';
import HookAppDemo from './components/HookAppDemo';
import NoteApp from './components/NoteApp';
import RestApp from './components/RestApp';
import ContextApp from './contexts/contextApp';

function App() {
  return (
    <div className="App">
      {/* <HookAppDemo/>
      <NoteApp/> */}
      <RestApp/>
      <ContextApp/>
    </div>
  );
}

export default App;
