
import React, {useEffect, useState} from 'react';

function HookAppDemo(props) {

    const [counter, setCounter] = useState(10)

    useEffect(()=> {
        console.log('load');
    }, [])

    useEffect(()=> {
        console.log('update');
    }, [counter])

    const increment=()=>{
        setCounter(counter+1)
    }

    const decrement=()=>{
        setCounter(counter-1)
    }

    const reset=()=>{
        setCounter(0)
    }
    return (
        <div>
            <p> Counter: {counter}</p>
            <button onClick={increment}> Increment</button>
            <button onClick={decrement}> Decrement</button>
            <button onClick={reset}> Reset</button>
        </div>
    );
}

export default HookAppDemo;