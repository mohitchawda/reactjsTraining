

import React, { useState } from 'react';

function NoteApp(props) {

    const [users, setUsers] =useState([])
    const [title, setTitle] =useState('')
    const [email, setEmail] =useState('')

    const addUser=(e)=>{
        e.preventDefault()
        setUsers([
            ...users, {title, email}
        ])

        setTitle('')
        setEmail('')
    }

    
  const deleteUser = (title) => {
    
    setUsers(
        users.filter((option) => option.title !== title)
    )
    };
  

    return (
        <div>
            {users.map((data) => (
                <ul key={data.title}>
                    <li>{data.title} || {data.email}</li>   
                    <button onClick={()=>deleteUser(data.title)}>delete</button>                 
                </ul>
        ))}

        <form onSubmit={addUser}>
            UserName: <input type='text' value={title} onChange={(e) => setTitle(e.target.value)}/>
            Email: <input type='text' value={email} onChange={(e) => setEmail(e.target.value)}/>
            <button>Add User</button>
        </form>
        </div>
    );
}

export default NoteApp;