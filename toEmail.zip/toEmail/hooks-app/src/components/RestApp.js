import axios from "axios";
import ShowData from "./ShowData";
import ShowDataButton from "./ShowDataButton";
import { useState } from "react";
const URL = "https://jsonplaceholder.typicode.com/users";
function RestApp(props){

    const [users, setUsers] =useState([])

  // cant use loadData(){} if we need to set state. setstate will work =>
  const loadData = (e) => {
    e.preventDefault()
    axios
      .get(URL)
      .then((res) => res.data)
      .then((data) => {
        setUsers(data)
      });
  };

    return (
      <div>
        <p>User Details</p>
        <ShowData user={users} />
        <ShowDataButton data={loadData} />
      </div>
    );

}

export default RestApp;