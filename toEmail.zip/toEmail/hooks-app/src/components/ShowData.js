function ShowData(props) {
  return (
    <div>
    {props.user.length >0 ?
    <table className="table">
      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
        </tr>
      </thead>
      <tbody>
        {" "}
        {props.user.map((udata) => (
          <tr key={udata.id}>
            <td> {udata.name}</td>
            <td> {udata.email}</td>
          </tr>
        ))}{" "}
      </tbody>
    </table>
    : null}
    </div>
  );
}

export default ShowData;
