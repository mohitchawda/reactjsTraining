function ShowDataButton(props) {
  return (
    <div>
      <button className="btn btn-success" onClick={props.data}>
        Load Data
      </button>
    </div>
  );
}

export default ShowDataButton;
