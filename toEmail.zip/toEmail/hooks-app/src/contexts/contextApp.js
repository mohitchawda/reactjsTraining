import React, { createContext, useContext, useState } from 'react';

const appContext = createContext()
const data={id:100,empName:'sandhya',location:'Hyd',salary:10000}
function ContextApp(props) {
    const [employee,setEmployee] = useState(data)
    return (
        <div>
            <p>Salary : {employee.salary}</p>
            <appContext.Provider value={{data: employee,updateEmployee: setEmployee}}>
           < Employee/>
           </appContext.Provider>
        </div>
    );
}

function Employee(props) {
    let empContext = useContext(appContext)
        function updateLocation(){
        empContext.updateEmployee({
            ...empContext.data,location:'Chennai',salary:20000
        })
    }
    return (
        <div>
            Employee Component 
            <p>Employee Id : {empContext.data.id}</p>
            <p>Employee Name : {empContext.data.empName}</p>
            <p>Employee Location: {empContext.data.location}</p>
            <p>Employee Salary: {empContext.data.salary}</p>
            <hr/>
            <button onClick={updateLocation}>Update Location</button>
            <Salary/>
        </div>
    );
}

function Salary(props) {
    let salaryContext = useContext(appContext)
    function updateIncome(){
        salaryContext.updateEmployee({
        ...salaryContext.data,salary:15000
        })
    }
   
    return (
        <div>
            Salary :
            <p>Employee Salary : {salaryContext.data.salary}</p>
            <hr/>
            <button onClick={updateIncome}>Update Salary</button>
            
        </div>
    );
}

export default ContextApp;