import { Component } from "react";

export default class CounterApp extends Component {
  state = {
    counter: 0,
  };

  increment = () => {
    this.setState((prevState) => {
      return {
        counter: prevState.counter + 1,
      };
    });
  };

  decrement = () => {
    this.setState((prevState) => {
      return {
        counter: prevState.counter - 1,
      };
    });
  };

  reset = () => {
    this.setState(() => {
      return {
        counter: 0,
      };
    });
  };
  render() {
    return (
      <div>
        <p> Counter: {this.state.counter} </p>
        <button onClick={this.increment}>Increment </button>
        <button onClick={this.decrement}>Decrement </button>
        <button onClick={this.reset}>Reset </button>
      </div>
    );
  }
}
