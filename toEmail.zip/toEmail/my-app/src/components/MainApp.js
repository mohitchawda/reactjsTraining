import { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import AddUser from "./AddUser";
import Users from "./Users";
import CounterApp from "./CounterApp";
import RestApp from "./RestApp";

export default class MainApp extends Component {
  state = {
    hm: "Header from props",
    fm: "Footer from props",
    userData: [],
  };

  addUser = (data) => {
    this.setState((prevState) => {
      return {
        userData: prevState.userData.concat(data),
      };
    });
  };

  deleteAllUser = () => {
    this.setState(() => {
      return {
        userData: [],
      };
    });
  };

  deleteUser = (user) => {
    this.setState((prevState) => {
      return {
        userData: prevState.userData.filter((option) => user !== option),
      };
    });
  };

  render() {
    return (
      <div>
        {/* <Header hm={this.state.hm} />
        <p>Welcome to MainApp</p>
        <Users
          userData={this.state.userData}
          du={this.deleteAllUser}
          dataSize={this.state.userData.length > 0}
          deleteuser={this.deleteUser}
        />
        <AddUser au={this.addUser} />
        <CounterApp /> */}
        <RestApp />
        {/* <Footer fm={this.state.fm} /> */}
      </div>
    );
  }
}
