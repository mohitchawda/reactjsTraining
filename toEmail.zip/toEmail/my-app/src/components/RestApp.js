import { Component } from "react";
import axios from "axios";
import ShowData from "./ShowData";
import ShowDataButton from "./ShowDataButton";
const URL = "https://jsonplaceholder.typicode.com/users";
export default class RestApp extends Component {

    // componentdidMount -> will be called automatically once component is loaded/refreshed
  // componentDidMount(){

  //     axios.get(URL).then(res=>res.data)
  //     .then((data) => {
  //         console.log(data);
  //     })
  // }

  state = {
    users: [],
  };

  // cant use loadData(){} if we need to set state. setstate will work =>
  loadData = () => {
    axios
      .get(URL)
      .then((res) => res.data)
      .then((data) => {
        this.setState({ users: data });
      });
  };
  render() {
    return (
      <div>
        <p>User Details</p>
        <ShowData user={this.state.users} />
        <ShowDataButton data={this.loadData} />
      </div>
    );
  }
}
