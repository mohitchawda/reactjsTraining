import { Component } from "react";

export default class User extends Component {
  render() {
    return (
      <div>
        Welcome {this.props.usr}
        <button onClick={() => this.props.duser(this.props.usr)}>delete</button>
      </div>
    );
  }
}
