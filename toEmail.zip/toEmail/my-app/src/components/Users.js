import { Component } from "react";
import User from "./User";

export default class Users extends Component {
  render() {
    return (
      <div>
        {this.props.userData.map((data) => (
          <User usr={data} duser={this.props.deleteuser} />
        ))}
        <button disabled={!this.props.dataSize} onClick={this.props.du}>
          Delete All
        </button>
      </div>
    );
  }
}
