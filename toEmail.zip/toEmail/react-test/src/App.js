
import React from 'react';

function App(props) {
    return (
        <div>
            Welcome
        </div>
    );
}

export default App;