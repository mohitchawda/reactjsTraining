import { useSelector } from "react-redux";


function AuthState(props) {

    const authState = useSelector(state =>state.auth)
    console.log(authState)

    return (
        <div>
            <h2>For Authorized user only.....</h2>
            {authState ? (
                <div>
                    <p>
                        Congratulations!!!!!!!<hr/>
                        Use coupon code: LKJHDW876
                    </p>
                </div>
            ): (<p>Please login to avail offers....</p>)}
        </div>
    );

}

export default AuthState