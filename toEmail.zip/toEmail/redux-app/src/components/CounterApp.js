import React from 'react';
import CounterState from './CounterState';
import CounterAction from './CounterAction';

function CounterApp(props) {

    return(
        <div>
            <CounterState/>
            <CounterAction/>

        </div>
    );

    /*  //useSelector is a predefined consumer hook which takes consumers the state from provider
     //'counter' is the name of the 'reducer which we are assigning in the register
    const mycount = useSelector(state1 => state1.counter)
    const dispatch = useDispatch()
    return (
        <div>
            <p>The count is : {mycount}</p>
            <button onClick={() => dispatch(increment())}>Increment </button>
            <button onClick={() => dispatch(decrement())}>Decrement</button>
            <button onClick={() => dispatch(reset())}>Reset </button>
        </div>
    ); */
}

export default CounterApp;