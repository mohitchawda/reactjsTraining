
import React from 'react';
import { useSelector } from 'react-redux';

function CounterState(props) {
     //useSelector is a predefined consumer hook which takes consumers the state from provider
     //'counter' is the name of the 'reducer which we are assigning in the register
    const mycount = useSelector(state1 => state1.counter)
    return (
        <div>
            <p>The count is : {mycount}</p>
        </div>
    );
}

export default CounterState;