function ShowUserData(props) {
    return (

        <div>
        {props.data.length >0 ?
        <table className="table">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">City</th>
            </tr>
          </thead>
          <tbody>
            {" "}
            {props.data.map((udata) => (
              <tr key={udata.id}>
                <td> {udata.name}</td>
                <td> {udata.email}</td>
                <td> {udata.address.city}</td>
              </tr>
            ))}{" "}
          </tbody>
        </table>
        : null}
        </div>

        );
}

export default ShowUserData;