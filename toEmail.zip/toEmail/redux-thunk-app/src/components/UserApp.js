import React, {useEffect} from 'react';
import {useSelector, useDispatch} from 'react-redux'
import {getUsers} from '../redux/appSlice'
import ShowUserData from './ShowUserData';
function UserApp(props) {

    const data = useSelector(state => state.userdata.users)
    const dispatch = useDispatch()

    const callUser = () => {
        dispatch(getUsers())
    }

    console.log(data);

    return(
        <div>
            <ShowUserData  data={data} />
            <button onClick={callUser}>Load Data</button>
        </div>
    )

}

export default UserApp;