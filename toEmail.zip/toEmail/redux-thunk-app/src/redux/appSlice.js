import {createAsyncThunk, createSlice} from '@reduxjs/toolkit'

export const getUsers = createAsyncThunk(
    'users/getUsers',
    async()=>{
        const response = await fetch('https://jsonplaceholder.typicode.com/users')
        const formattedres = await response.json()
        return formattedres

    })
    export const userSlice = createSlice({

        name: 'userdata',
        initialState: {
            users:[],
            loading: false
    },
    extraReducers:{

        [getUsers.pending] : (state) => {
            state.loading = true
        },
        [getUsers.fulfilled] : (state, action) => {
            state.users = action.payload
            state.loading = false
        },
        [getUsers.rejected] : (state) => {
            state.loading = false
        },
    }
})

export default userSlice.reducer