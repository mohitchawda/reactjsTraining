import React from 'react';
import CounterState from './CounterState';
import CounterAction from './CounterAction';

function CounterApp(props) {

    return(
        <div>
            <CounterState/>
            <CounterAction/>

        </div>
    );
}

export default CounterApp;