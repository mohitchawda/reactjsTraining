import React, {useState} from 'react';
import { addUserToDB, loadUserList } from '../redux/actions/userAction';
import { useDispatch, useSelector } from 'react-redux'

function EditUser({history}) {

    const[name, setName] = useState('')
    const[email, setEmail] = useState('')
    const[city, setCity] = useState('')
    const[role, setRole] = useState('')
    
    const dispatch = useDispatch()

    const addUser=(e) =>{
        e.preventDefault()
        console.log('User Added')
        const userobj = {name, email, city, role}
        dispatch(addUserToDB(userobj))
        dispatch(loadUserList)
        history.push('userdetails')
    }


    return (
        <div>
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">User Registration</h5>
                <br/>
                <form onSubmit={addUser}>
                    UserName:<input type='text' onChange={e => setName(e.target.value)} className='form-control'/>
                    Email:<input type='text' onChange={e => setEmail(e.target.value)} className='form-control'/>
                    City:<input type='text' onChange={e => setCity(e.target.value)} className='form-control'/>
                    Role:<select onChange={e => setRole(e.target.value)} className='form-control'>
                        <option value='admin'>Admin</option>
                        <option value='QA'>QA</option>
                        <option value='Manager'>Manager</option>
                    </select> <br/>
                    <button type="submit" class="btn btn-primary mb-3">Add User</button>                   
                </form>
            </div>
            </div>
        </div>
    );
}

export default EditUser;