import React from 'react';

function LandingPage() {
    return (
        <div>
            <p>Welcome to JPMC India</p>

            <hr/>

        </div>
    );


}


export default LandingPage;
