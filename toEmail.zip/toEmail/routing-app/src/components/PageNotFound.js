import React from 'react';

function PageNotFound(props) {
    return (
        <div>
            OOPS...Page not Found !!
        </div>
    );
}

export default PageNotFound;