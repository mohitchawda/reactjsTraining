import React, {useState} from 'react';
import { addUserToDB, loadUserList } from '../redux/actions/userAction';
import { useDispatch, useSelector } from 'react-redux'

function Register({history}) {

    const[name, setName] = useState('')
    const[email, setEmail] = useState('')
    const[city, setCity] = useState('')
    const[role, setRole] = useState('')
    const[gender, setGender] = useState('')
    const[language, setLanguage] = useState('')
    
    const dispatch = useDispatch()

    const addUser=(e) =>{
        e.preventDefault()
        console.log('User Added')
        const userobj = {name, email, city, role, gender, language}
        dispatch(addUserToDB(userobj))
        dispatch(loadUserList)
        history.push('userdetails')
    }


    return (
        <div>
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">User Registration</h5>
                <br/>
                <form onSubmit={addUser}>
                    UserName:<input type='text' onChange={e => setName(e.target.value)} className='form-control'/>
                    Email:<input type='text' onChange={e => setEmail(e.target.value)} className='form-control'/>
                    City:<input type='text' onChange={e => setCity(e.target.value)} className='form-control'/>
                    Role:<select onChange={e => setRole(e.target.value)} className='form-control'>
                        <option value='admin'>Admin</option>
                        <option value='QA'>QA</option>
                        <option value='Manager'>Manager</option>
                    </select>
                    Gender:<div class="form-check">
                        <input class="form-check-input"  onChange={e => setGender(e.target.value)} value="Male" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
                        <label class="form-check-label" for="flexRadioDefault1">
                            Male
                        </label>
                        </div>
                        <div class="form-check">
                        <input class="form-check-input"  onChange={e => setGender(e.target.value)} value="Female" type="radio" name="flexRadioDefault" id="flexRadioDefault2"/>
                        <label class="form-check-label" for="flexRadioDefault2">
                            Female
                        </label>                        
                        </div>
                    Fav Language:
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"/>
                        <label class="form-check-label" for="flexCheckDefault">
                            Java
                        </label>
                        </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault1"/>
                        <label class="form-check-label" for="flexCheckDefault1">
                            Python
                        </label>
                        </div>
 <br/>
                    <button type="submit" class="btn btn-primary mb-3">Add User</button>                   
                </form>
            </div>
            </div>
        </div>
    );
}

export default Register;