import Login from './Login';
import Register from './Register';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import UserDetails from './UserDetails';
import UserPortfolio from './UserPortfolio';
import PageNotFound from './PageNotFound';
import NavigationLink from './NavigationLink';
import LandingPage from './LandingPage';
import EditUser from './EditUser';
function Routes(){
    
    return (

    <BrowserRouter>
    <div>
        <NavigationLink/>
    <Switch>
            <Route path="/" exact={true} component={LandingPage}/>
            <Route path="/login" component={Login}/>
            <Route path="/register" component={Register}/>
            <Route path="/userdetails" component={UserDetails}/>
            <Route path="/edit" component={EditUser}/>
            <Route path="/portfolio" component={UserPortfolio}/>
            <Route component={PageNotFound}/>
    </Switch>
    </div>
    </BrowserRouter>

)}

export default Routes