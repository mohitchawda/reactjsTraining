import React from 'react';
function UserPortfolio(props) {

    return(
        <div>
            <p>Welcome to UserPortfolio</p>
        </div>
    )

}

export default UserPortfolio;